package com.scb.demo.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Test {
	public static void main(String[] args) throws Exception{
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		String date1 = df.format(new Date());
		System.out.println(date1);
		Date date = df.parse("2022-12-31");
		System.out.println(date);
	}

}
