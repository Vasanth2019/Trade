package com.scb.demo.service;
import java.util.List;

import com.scb.demo.model.Product;
public interface IProductService 
{
List<Product> findAll();
}
